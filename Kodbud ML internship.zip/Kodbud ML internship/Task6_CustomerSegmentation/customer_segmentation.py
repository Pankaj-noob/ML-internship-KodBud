import os
import sys
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans

np.random.seed(42)

print("=" * 60)
print("CUSTOMER SEGMENTATION (K-Means Clustering)")
print("=" * 60)

file_name = 'Mall_Customers.csv'
url = 'https://raw.githubusercontent.com/tirthajyoti/Machine-Learning-with-Python/master/Datasets/Mall_Customers.csv'

if not os.path.exists(file_name):
    print(f"\nDownloading dataset from GitHub...")
    try:
        temp_df = pd.read_csv(url)
        temp_df.to_csv(file_name, index=False)
        print(f"[OK] Saved '{file_name}' ({len(temp_df)} rows)")
    except Exception as e:
        print(f"\n[ERROR] Download failed: {e}")
        print(f"Please place '{file_name}' manually in this folder:")
        print(f"  {os.getcwd()}")
        sys.exit(1)
else:
    print(f"\n[OK] '{file_name}' already exists locally.")

print("\n" + "=" * 60)
print("STEP 1: EXPLORATORY DATA ANALYSIS")
print("=" * 60)

mydf = pd.read_csv(file_name)

print(f"\nDataset shape: {mydf.shape}")
print(f"\nColumns: {mydf.columns.tolist()}")

print("\n-- First 5 Rows --")
print(mydf.head().to_string())

print("\n-- Missing Values --")
print(mydf.isnull().sum())
print(f"\nTotal missing values: {mydf.isnull().sum().sum()}")

print("\n-- Descriptive Statistics --")
print(mydf.describe().to_string())

fig, axes = plt.subplots(1, 2, figsize=(14, 5))

sns.histplot(mydf['Annual Income (k$)'], kde=True, color='#3498DB',
             ax=axes[0], bins=20, edgecolor='black', linewidth=0.5)
axes[0].set_title('Distribution of Annual Income (k$)',
                  fontsize=13, fontweight='bold')
axes[0].set_xlabel('Annual Income (k$)')
axes[0].set_ylabel('Count')

sns.histplot(mydf['Spending Score (1-100)'], kde=True, color='#E74C3C',
             ax=axes[1], bins=20, edgecolor='black', linewidth=0.5)
axes[1].set_title('Distribution of Spending Score (1-100)',
                  fontsize=13, fontweight='bold')
axes[1].set_xlabel('Spending Score (1-100)')
axes[1].set_ylabel('Count')

plt.tight_layout()
plt.savefig('feature_distributions.png', dpi=150, bbox_inches='tight')
plt.show()
print("\n[OK] Saved 'feature_distributions.png'")

print("\n" + "=" * 60)
print("STEP 2: FEATURE SELECTION & SCALING")
print("=" * 60)

my_cols = ['Annual Income (k$)', 'Spending Score (1-100)']
x_raw = mydf[my_cols].values

print(f"\nSelected features: {my_cols}")
print(f"Feature matrix shape: {x_raw.shape}")

my_scaler = StandardScaler()
x_norm = my_scaler.fit_transform(x_raw)

print(f"\nBefore scaling:")
print(f"  Income   - Mean: {x_raw[:, 0].mean():.2f}, Std: {x_raw[:, 0].std():.2f}")
print(f"  Spending - Mean: {x_raw[:, 1].mean():.2f}, Std: {x_raw[:, 1].std():.2f}")
print(f"\nAfter scaling:")
print(f"  Income   - Mean: {x_norm[:, 0].mean():.2f}, Std: {x_norm[:, 0].std():.2f}")
print(f"  Spending - Mean: {x_norm[:, 1].mean():.2f}, Std: {x_norm[:, 1].std():.2f}")

print("\n" + "=" * 60)
print("STEP 3: ELBOW METHOD")
print("=" * 60)

loss_list = []
k_vals = range(1, 11)

for k in k_vals:
    km = KMeans(n_clusters=k, n_init=10, random_state=42)
    km.fit(x_norm)
    loss_list.append(km.inertia_)

print("\n-- Inertia Values --")
for k, val in zip(k_vals, loss_list):
    marker = " <-- likely elbow" if k == 5 else ""
    print(f"  k={k:2d}:  Inertia = {val:.4f}{marker}")

fig, ax = plt.subplots(figsize=(9, 6))
ax.plot(k_vals, loss_list, 'bo-', linewidth=2, markersize=8)
ax.axvline(x=5, color='red', linestyle='--', linewidth=1.5, alpha=0.7,
           label='Optimal k=5')
ax.set_xlabel('Number of Clusters (k)', fontsize=12)
ax.set_ylabel('Inertia (Within-Cluster Sum of Squares)', fontsize=12)
ax.set_title('Elbow Method - Optimal Number of Clusters',
             fontsize=14, fontweight='bold')
ax.set_xticks(k_vals)
ax.legend(fontsize=11)
ax.grid(alpha=0.3)

plt.tight_layout()
plt.savefig('elbow_method.png', dpi=150, bbox_inches='tight')
plt.show()
print("\n[OK] Saved 'elbow_method.png'")

print("\n" + "=" * 60)
print("STEP 4: K-MEANS CLUSTERING (k=5)")
print("=" * 60)

best_k = 5
final_km = KMeans(n_clusters=best_k, n_init=10, random_state=42)
my_clusters = final_km.fit_predict(x_norm)

mydf['Cluster'] = my_clusters

print(f"\nFinal model: KMeans(n_clusters={best_k}, n_init=10, random_state=42)")
print(f"Inertia: {final_km.inertia_:.4f}")

centers_norm = final_km.cluster_centers_
centers_raw = my_scaler.inverse_transform(centers_norm)

print("\n-- Cluster Centers (Original Scale) --")
centers_table = pd.DataFrame(
    centers_raw,
    columns=['Annual Income (k$)', 'Spending Score (1-100)']
)
centers_table.index.name = 'Cluster'
print(centers_table.to_string())

print("\n-- Customers Per Cluster --")
counts = mydf['Cluster'].value_counts().sort_index()
for c_id, num in counts.items():
    print(f"  Cluster {c_id}: {num} customers")

print("\n" + "=" * 60)
print("STEP 5: CLUSTER VISUALIZATION")
print("=" * 60)

my_colors = ['#3498DB', '#E74C3C', '#2ECC71', '#F39C12', '#9B59B6']

fig, ax = plt.subplots(figsize=(10, 8))

for i in range(best_k):
    m = my_clusters == i
    ax.scatter(
        x_raw[m, 0], x_raw[m, 1],
        c=my_colors[i], s=60, alpha=0.7,
        edgecolors='k', linewidth=0.4,
        label=f'Cluster {i}'
    )

ax.scatter(
    centers_raw[:, 0], centers_raw[:, 1],
    c='red', marker='X', s=250, linewidths=2,
    edgecolors='black', zorder=5,
    label='Centroids'
)

ax.set_xlabel('Annual Income (k$)', fontsize=12)
ax.set_ylabel('Spending Score (1-100)', fontsize=12)
ax.set_title('Customer Segmentation - K-Means Clustering (k=5)',
             fontsize=14, fontweight='bold')
ax.legend(fontsize=10, loc='upper right')
ax.grid(alpha=0.3)

plt.tight_layout()
plt.savefig('customer_clusters.png', dpi=150, bbox_inches='tight')
plt.show()
print("[OK] Saved 'customer_clusters.png'")

print("\n" + "=" * 60)
print("STEP 6: BUSINESS INTERPRETATION")
print("=" * 60)

profile_list = []
for i in range(best_k):
    inc = centers_raw[i, 0]
    spd = centers_raw[i, 1]

    if inc > 70:
        lvl1 = "High income"
    elif inc > 45:
        lvl1 = "Medium income"
    else:
        lvl1 = "Low income"

    if spd > 65:
        lvl2 = "high spending"
    elif spd > 35:
        lvl2 = "medium spending"
    else:
        lvl2 = "low spending"

    if lvl1 == "High income" and lvl2 == "high spending":
        msg = "Premium customers - target with luxury products and loyalty programs"
    elif lvl1 == "High income" and lvl2 == "low spending":
        msg = "Careful savers - potential to convert with personalized offers"
    elif lvl1 == "Low income" and lvl2 == "high spending":
        msg = "Impulsive spenders - offer budget-friendly deals and installment plans"
    elif lvl1 == "Low income" and lvl2 == "low spending":
        msg = "Budget-conscious - attract with discounts and value bundles"
    else:
        msg = "Average customers - maintain engagement with standard marketing"

    profile_list.append({
        'Cluster': i,
        'Avg Income (k$)': round(inc, 1),
        'Avg Spending': round(spd, 1),
        'Profile': f"{lvl1}, {lvl2}",
        'Business Action': msg
    })

print()
for p in profile_list:
    print(f"  Cluster {p['Cluster']}: {p['Profile']}")
    print(f"    Income: ${p['Avg Income (k$)']}k  |  Spending Score: {p['Avg Spending']}")
    print(f"    --> {p['Business Action']}")
    print()

print("=" * 60)
print("FINAL SUMMARY")
print("=" * 60)
print(f"""
  Dataset:        Mall Customers ({mydf.shape[0]} customers)
  Features Used:  Annual Income (k$), Spending Score (1-100)
  Algorithm:      K-Means Clustering (k={best_k})
  Preprocessing:  StandardScaler (critical for distance-based methods)

  --- Files Saved ---
  1. feature_distributions.png   (EDA distributions)
  2. elbow_method.png            (Optimal k selection)
  3. customer_clusters.png       (Final cluster visualization)
""")
print("=" * 60)
print("ALL TASKS COMPLETED SUCCESSFULLY")
print("=" * 60)
