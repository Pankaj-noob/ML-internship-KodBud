import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    confusion_matrix, ConfusionMatrixDisplay, classification_report
)

print("=" * 60)
print("TITANIC SURVIVAL PREDICTION")
print("=" * 60)

mydf = sns.load_dataset('titanic')

print(f"\nDataset shape: {mydf.shape}")
print(f"\n-- First 5 Rows --")
print(mydf.head().to_string())

print(f"\n-- Column Data Types --")
print(mydf.dtypes)

print("\n" + "=" * 60)
print("DATA CLEANING")
print("=" * 60)

print("\n-- Missing Values (Before Cleaning) --")
miss = mydf.isnull().sum()
print(miss[miss > 0])

age_mid = mydf['age'].median()
mydf['age'] = mydf['age'].fillna(age_mid)
print(f"\n[OK] 'age' missing values filled with median: {age_mid}")

emb_most = mydf['embarked'].mode()[0]
mydf['embarked'] = mydf['embarked'].fillna(emb_most)
print(f"[OK] 'embarked' missing values filled with mode: {emb_most}")

mydf = mydf.drop(columns=['deck', 'embark_town', 'alive', 'who', 'adult_male',
                           'class', 'alone'])

print("\n-- Missing Values (After Cleaning) --")
left = mydf.isnull().sum()
left_missing = left[left > 0]
if len(left_missing) == 0:
    print("No missing values remain!")
else:
    print(left_missing)

print(f"\n-- Cleaned Dataset Shape: {mydf.shape} --")
print(mydf.head().to_string())

print("\n" + "=" * 60)
print("FEATURE ENCODING")
print("=" * 60)

encoded_df = pd.get_dummies(mydf, columns=['sex', 'embarked'], drop_first=True)

print("\n-- Encoded Features --")
print(encoded_df.columns.tolist())
print(f"\nEncoded dataset shape: {encoded_df.shape}")
print(encoded_df.head().to_string())

x = encoded_df.drop(columns=['survived'])
y = encoded_df['survived']

x_train, x_test, y_train, y_test = train_test_split(
    x, y, test_size=0.2, random_state=42, stratify=y
)

print(f"\n-- Train/Test Split --")
print(f"Training set size: {x_train.shape[0]}")
print(f"Testing set size:  {x_test.shape[0]}")
print(f"Survival rate (train): {y_train.mean():.2%}")
print(f"Survival rate (test):  {y_test.mean():.2%}")

print("\n" + "=" * 60)
print("MODEL TRAINING & EVALUATION")
print("=" * 60)


def check_model(name, model, x_train, x_test, y_train, y_test):
    model.fit(x_train, y_train)
    pred = model.predict(x_test)

    acc = accuracy_score(y_test, pred)
    prec = precision_score(y_test, pred)
    rec = recall_score(y_test, pred)
    f1 = f1_score(y_test, pred)

    print(f"\n-- {name} --")
    print(f"  Accuracy:  {acc:.4f}  ({acc * 100:.2f}%)")
    print(f"  Precision: {prec:.4f}")
    print(f"  Recall:    {rec:.4f}")
    print(f"  F1-Score:  {f1:.4f}")
    print(f"\n  Classification Report:")
    print(classification_report(y_test, pred, target_names=['Did Not Survive', 'Survived']))

    return pred


rf = RandomForestClassifier(n_estimators=100, random_state=42)
rf_pred = check_model("Random Forest", rf, x_train, x_test, y_train, y_test)

lr = LogisticRegression(max_iter=1000, random_state=42)
lr_pred = check_model("Logistic Regression", lr, x_train, x_test, y_train, y_test)

print("\n" + "=" * 60)
print("VISUALIZATIONS")
print("=" * 60)

rf_matrix = confusion_matrix(y_test, rf_pred)

fig, ax = plt.subplots(figsize=(7, 5))
d = ConfusionMatrixDisplay(
    confusion_matrix=rf_matrix,
    display_labels=['Did Not Survive', 'Survived']
)
d.plot(ax=ax, cmap='Blues', colorbar=True)
ax.set_title('Random Forest - Confusion Matrix', fontsize=14, fontweight='bold')
plt.tight_layout()
plt.savefig('rf_confusion_matrix.png', dpi=150, bbox_inches='tight')
plt.show()
print("[OK] Confusion matrix saved as 'rf_confusion_matrix.png'")

viz_df = sns.load_dataset('titanic')

rates = viz_df.groupby(['pclass', 'sex'])['survived'].mean().unstack()

fig, ax = plt.subplots(figsize=(9, 6))

positions = np.arange(len(rates.index))
bar_width = 0.35

bars1 = ax.bar(positions - bar_width/2, rates['female'], bar_width,
               label='Female', color='#E74C3C', edgecolor='black', linewidth=0.5)
bars2 = ax.bar(positions + bar_width/2, rates['male'], bar_width,
               label='Male', color='#3498DB', edgecolor='black', linewidth=0.5)

for b in bars1:
    h = b.get_height()
    ax.text(b.get_x() + b.get_width()/2., h + 0.01,
            f'{h:.1%}', ha='center', va='bottom', fontweight='bold', fontsize=10)
for b in bars2:
    h = b.get_height()
    ax.text(b.get_x() + b.get_width()/2., h + 0.01,
            f'{h:.1%}', ha='center', va='bottom', fontweight='bold', fontsize=10)

ax.set_xlabel('Passenger Class', fontsize=12)
ax.set_ylabel('Survival Rate', fontsize=12)
ax.set_title('Titanic Survival Rate by Passenger Class and Sex',
             fontsize=14, fontweight='bold')
ax.set_xticks(positions)
ax.set_xticklabels(['1st Class', '2nd Class', '3rd Class'])
ax.set_ylim(0, 1.1)
ax.legend(fontsize=11)
ax.grid(axis='y', alpha=0.3)

plt.tight_layout()
plt.savefig('survival_rate_by_class_sex.png', dpi=150, bbox_inches='tight')
plt.show()
print("[OK] Survival rate chart saved as 'survival_rate_by_class_sex.png'")

print("\n" + "=" * 60)
print("ALL TASKS COMPLETED SUCCESSFULLY")
print("=" * 60)
