import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.datasets import fetch_california_housing
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

np.random.seed(42)

print("=" * 60)
print("HOUSE PRICE PREDICTION (Linear Regression)")
print("=" * 60)

data = fetch_california_housing()
mydf = pd.DataFrame(data=data.data, columns=data.feature_names)
mydf['Price'] = data.target

print(f"\nDataset shape: {mydf.shape}")
print(f"Target: Price (in $100,000s)")

print("\n-- First 5 Rows --")
print(mydf.head().to_string())

print("\n-- Missing Values --")
miss = mydf.isnull().sum()
print(miss)
print(f"\nTotal missing values: {miss.sum()}")

print("\n-- Descriptive Statistics --")
print(mydf.describe().to_string())

print("\n-- Correlation with Price --")
corr = mydf.corr()['Price'].drop('Price').sort_values(ascending=False)
print(corr.to_string())

print("\n-- Top 3 Features Most Correlated with Price --")
top = corr.abs().sort_values(ascending=False).head(3)
for i, (feat, val) in enumerate(top.items(), 1):
    real_corr = corr[feat]
    print(f"  {i}. {feat}: {real_corr:.4f}")

plt.figure(figsize=(12, 9))
hm = sns.heatmap(
    mydf.corr(),
    annot=True,
    fmt='.2f',
    cmap='RdBu_r',
    center=0,
    square=True,
    linewidths=0.5,
    cbar_kws={'shrink': 0.8}
)
plt.title('Correlation Heatmap - California Housing Dataset',
          fontsize=14, fontweight='bold', pad=15)
plt.tight_layout()
plt.savefig('correlation_heatmap.png', dpi=150, bbox_inches='tight')
plt.show()
print("\n[OK] Saved 'correlation_heatmap.png'")

print("\n" + "=" * 60)
print("PREPROCESSING")
print("=" * 60)

x = mydf.drop(columns=['Price'])
y = mydf['Price']

print(f"\nFeatures shape: {x.shape}")
print(f"Target shape:   {y.shape}")

x_train, x_test, y_train, y_test = train_test_split(
    x, y, test_size=0.2, random_state=42
)

print(f"\nTraining set: {x_train.shape[0]} samples")
print(f"Testing set:  {x_test.shape[0]} samples")

pipe = Pipeline([
    ('scaler', StandardScaler()),
    ('regressor', LinearRegression())
])

print("\n-- Pipeline Architecture --")
print(pipe)

print("\n" + "=" * 60)
print("TRAINING & EVALUATION")
print("=" * 60)

pipe.fit(x_train, y_train)

predicted = pipe.predict(x_test)

mae_val = mean_absolute_error(y_test, predicted)
mse_val = mean_squared_error(y_test, predicted)
rmse_val = np.sqrt(mse_val)
r2_val = r2_score(y_test, predicted)

print(f"\n-- Model Performance Metrics --")
print(f"  MAE  (Mean Absolute Error):   {mae_val:.4f}  (${mae_val * 100000:,.0f})")
print(f"  MSE  (Mean Squared Error):    {mse_val:.4f}")
print(f"  RMSE (Root Mean Squared Err): {rmse_val:.4f}  (${rmse_val * 100000:,.0f})")
print(f"  R2   (R-squared Score):       {r2_val:.4f}  ({r2_val * 100:.2f}%)")

print("\n-- Feature Coefficients --")
my_model = pipe.named_steps['regressor']
my_scaler = pipe.named_steps['scaler']
coeff_table = pd.DataFrame({
    'Feature': x.columns,
    'Coefficient': my_model.coef_
}).sort_values('Coefficient', ascending=False)
print(coeff_table.to_string(index=False))
print(f"\n  Intercept: {my_model.intercept_:.4f}")

print("\n" + "=" * 60)
print("VISUALIZATIONS")
print("=" * 60)

fig1, ax1 = plt.subplots(figsize=(8, 8))
ax1.scatter(y_test, predicted, alpha=0.4, edgecolors='k', linewidth=0.3,
           color='#3498DB', s=30, label='Predictions')

low = min(y_test.min(), predicted.min())
high = max(y_test.max(), predicted.max())
ax1.plot([low, high], [low, high], 'r-', linewidth=2,
        label='Perfect Prediction (y=x)')

ax1.set_xlabel('Actual Price ($100,000s)', fontsize=12)
ax1.set_ylabel('Predicted Price ($100,000s)', fontsize=12)
ax1.set_title('Actual vs Predicted House Prices',
             fontsize=14, fontweight='bold')
ax1.legend(fontsize=11)
ax1.grid(alpha=0.3)
ax1.set_aspect('equal', adjustable='box')

plt.tight_layout()
plt.savefig('actual_vs_predicted.png', dpi=150, bbox_inches='tight')
plt.show()
print("[OK] Saved 'actual_vs_predicted.png'")

errors = y_test - predicted

fig2, ax2 = plt.subplots(figsize=(10, 6))
ax2.scatter(predicted, errors, alpha=0.4, edgecolors='k', linewidth=0.3,
           color='#E74C3C', s=30)
ax2.axhline(y=0, color='black', linewidth=2, linestyle='--', label='Zero Residual')

ax2.set_xlabel('Predicted Price ($100,000s)', fontsize=12)
ax2.set_ylabel('Residuals (Actual - Predicted)', fontsize=12)
ax2.set_title('Residual Plot - Linear Regression',
             fontsize=14, fontweight='bold')
ax2.legend(fontsize=11)
ax2.grid(alpha=0.3)

plt.tight_layout()
plt.savefig('residual_plot.png', dpi=150, bbox_inches='tight')
plt.show()
print("[OK] Saved 'residual_plot.png'")

print("\n" + "=" * 60)
print("FINAL SUMMARY")
print("=" * 60)
print(f"""
  Dataset:       California Housing ({mydf.shape[0]} samples, {mydf.shape[1] - 1} features)
  Model:         Linear Regression (with StandardScaler pipeline)
  Train/Test:    80/20 split (random_state=42)

  --- Metrics ---
  MAE:           {mae_val:.4f}  (${mae_val * 100000:,.0f})
  MSE:           {mse_val:.4f}
  RMSE:          {rmse_val:.4f}  (${rmse_val * 100000:,.0f})
  R2 Score:      {r2_val:.4f}  ({r2_val * 100:.2f}% variance explained)

  --- Files Saved ---
  1. correlation_heatmap.png
  2. actual_vs_predicted.png
  3. residual_plot.png
""")
print("=" * 60)
print("ALL TASKS COMPLETED SUCCESSFULLY")
print("=" * 60)
