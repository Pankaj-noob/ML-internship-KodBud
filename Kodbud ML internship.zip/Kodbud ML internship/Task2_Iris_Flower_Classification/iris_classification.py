import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, confusion_matrix, ConfusionMatrixDisplay

data = load_iris()
mydf = pd.DataFrame(data=data.data, columns=data.feature_names)
mydf['species'] = pd.Categorical.from_codes(data.target, data.target_names)

print("=" * 60)
print("IRIS FLOWER CLASSIFICATION")
print("=" * 60)

print("\n-- First 5 Rows --")
print(mydf.head().to_string())

print("\n-- Missing Values --")
print(mydf.isnull().sum())
print(f"\nTotal missing values: {mydf.isnull().sum().sum()}")

print("\n-- Summary Statistics --")
print(mydf.describe().to_string())

print("\n-- Dataset Info --")
print(f"Shape: {mydf.shape}")
print(f"\nClass Distribution:\n{mydf['species'].value_counts().to_string()}")

x = mydf[data.feature_names]
y = data.target

x_train, x_test, y_train, y_test = train_test_split(
    x, y, test_size=0.2, random_state=42, stratify=y
)

print(f"\n-- Train/Test Split --")
print(f"Training set size: {x_train.shape[0]}")
print(f"Testing set size:  {x_test.shape[0]}")

knn_model = KNeighborsClassifier(n_neighbors=3)
knn_model.fit(x_train, y_train)
knn_pred = knn_model.predict(x_test)

knn_acc = accuracy_score(y_test, knn_pred)
knn_matrix = confusion_matrix(y_test, knn_pred)

print("\n" + "=" * 60)
print("MODEL EVALUATION")
print("=" * 60)
print(f"\n-- KNN (k=3) --")
print(f"Accuracy: {knn_acc:.4f} ({knn_acc * 100:.2f}%)")
print(f"Confusion Matrix:\n{knn_matrix}")

lr_model = LogisticRegression(max_iter=200, random_state=42)
lr_model.fit(x_train, y_train)
lr_pred = lr_model.predict(x_test)

lr_acc = accuracy_score(y_test, lr_pred)
lr_matrix = confusion_matrix(y_test, lr_pred)

print(f"\n-- Logistic Regression --")
print(f"Accuracy: {lr_acc:.4f} ({lr_acc * 100:.2f}%)")
print(f"Confusion Matrix:\n{lr_matrix}")

fig, axes = plt.subplots(1, 2, figsize=(12, 5))

d1 = ConfusionMatrixDisplay(
    confusion_matrix=knn_matrix,
    display_labels=data.target_names
)
d1.plot(ax=axes[0], cmap='Blues', colorbar=False)
axes[0].set_title('KNN (k=3) - Confusion Matrix', fontsize=13, fontweight='bold')

d2 = ConfusionMatrixDisplay(
    confusion_matrix=lr_matrix,
    display_labels=data.target_names
)
d2.plot(ax=axes[1], cmap='Greens', colorbar=False)
axes[1].set_title('Logistic Regression - Confusion Matrix', fontsize=13, fontweight='bold')

plt.suptitle(
    f'Model Comparison  |  KNN Acc: {knn_acc:.2%}  •  LR Acc: {lr_acc:.2%}',
    fontsize=14, y=1.02
)
plt.tight_layout()
plt.savefig('confusion_matrices.png', dpi=150, bbox_inches='tight')
plt.show()
print("\n[OK] Confusion matrix plot saved as 'confusion_matrices.png'")

print("Generating pairplot (this may take a moment)...")

my_pairplot = sns.pairplot(
    mydf,
    hue='species',
    palette='husl',
    diag_kind='kde',
    plot_kws={'alpha': 0.7, 'edgecolor': 'k', 'linewidth': 0.3},
    height=2.5
)
my_pairplot.figure.suptitle('Iris Dataset - Pairplot by Species', y=1.02, fontsize=16, fontweight='bold')
plt.savefig('pairplot.png', dpi=150, bbox_inches='tight')
plt.show()
print("[OK] Pairplot saved as 'pairplot.png'")

print("\n" + "=" * 60)
print("ALL TASKS COMPLETED SUCCESSFULLY")
print("=" * 60)
